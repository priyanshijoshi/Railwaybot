import React, { useRef, useState } from "react"; 
import { useNavigate } from "react-router-dom"; 
import Chatbot from "../components/Chatbot";  
import Footer from "../components/Footer";
import Navigation from "../components/Navigation";  
import "../styles/Home.css"; 
import { FaRobot, FaInfoCircle } from 'react-icons/fa'; // Import FaRobot and remove unused icons

function Home() {
  const [isChatbotOpen, setIsChatbotOpen] = useState(false);

  const updates = [
    {
      img: "https://images.indianrailways.gov.in/railways/images/banner1.jpg",
      title: "New Vande Bharat Express",
      text: "Introducing new Vande Bharat Express routes connecting major cities with enhanced speed and comfort.",
      date: "June 20, 2024"
    },
    {
      img: "https://images.indianrailways.gov.in/railways/images/banner2.jpg",
      title: "Digital Ticketing Updates",
      text: "Enhanced digital ticketing system with improved user interface and faster booking experience.",
      date: "June 18, 2024"
    },
    {
      img: "https://images.indianrailways.gov.in/railways/images/banner3.jpg",
      title: "Safety Measures Enhancement",
      text: "Implementation of new safety protocols and modern tracking systems across all routes.",
      date: "June 15, 2024"
    }
  ];

  return (
    <div className="railway-home">
      <Navigation />
      <div className="hero-section">
        <div className="hero-content">
          <h1>Welcome to Indian Railways</h1>
          <p>Your Journey, Our Priority</p>
          <button className="chatbot-open-btn" onClick={() => setIsChatbotOpen(true)}>
            <FaRobot /> Chat with Assistant
          </button>
        </div>
      </div>

      {isChatbotOpen && <Chatbot onClose={() => setIsChatbotOpen(false)} />}

      {/* Latest Updates Section */}
      <div className="container latest-updates">
        <h2 className="section-title">Latest Updates</h2>
        <div className="row">
          {updates.map((update, index) => (
            <div className="col-md-4 mb-4" key={index}>
              <div className="news-card">
                <div className="news-img">
                  <img src={update.img} alt={update.title} />
                </div>
                <div className="news-content">
                  <span className="news-date">{update.date}</span>
                  <h5>{update.title}</h5>
                  <p>{update.text}</p>
                  <button className="read-more">
                    Read More <FaInfoCircle />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <Footer />
    </div>
  );
}

export default Home;