import React from "react";
import Navigation from "../components/Navigation";
import InputField from "../components/Chatbot";
import { FaTrain, FaCheckCircle, FaClock, FaPhoneAlt, FaEnvelope, FaMapMarkerAlt } from "react-icons/fa";
import "../styles/About.css";

const About = () => {
  return (
    <div className="about-page">
      <Navigation />
      <InputField />

      {/* Hero Section */}
      <div className="about-hero">
        <div className="container">
          <h1>Welcome to Indian Railways</h1>
          <p className="lead">Connecting India with Comfort and Reliability</p>
        </div>
      </div>

      {/* Main Content */}
      <div className="container about-content">
        <div className="row">
          <div className="col-md-6">
            <div className="about-card">
              <h2>About Us</h2>
              <p className="about-text">
                Welcome to Indian Railways' digital platform. With over 150 years of heritage, we're not just a transportation system - we're the lifeline of the nation, connecting dreams, people, and possibilities across the vast Indian landscape.
              </p>
            </div>
          </div>
          <div className="col-md-6">
            <div className="stats-container">
              <div className="stat-item">
                <h3>12,000+</h3>
                <p>Daily Trains</p>
              </div>
              <div className="stat-item">
                <h3>7,325</h3>
                <p>Stations</p>
              </div>
              <div className="stat-item">
                <h3>23M+</h3>
                <p>Daily Passengers</p>
              </div>
              <div className="stat-item">
                <h3>67,368</h3>
                <p>Route Kilometers</p>
              </div>
            </div>
          </div>
        </div>

        {/* Services Section */}
        <section className="services-section">
          <h2 className="section-title">Our Services</h2>
          <div className="row">
            {[
              { icon: <FaTrain />, title: "PNR Status", desc: "Real-time tracking of your booking status" },
              { icon: <FaCheckCircle />, title: "Easy Booking", desc: "Seamless ticket booking experience" },
              { icon: <FaClock />, title: "Live Updates", desc: "Stay informed with live train status" },
              { icon: <FaPhoneAlt />, title: "24/7 Support", desc: "Round-the-clock customer assistance" }
            ].map((service, index) => (
              <div key={index} className="col-md-3">
                <div className="service-card">
                  <div className="service-icon">{service.icon}</div>
                  <h3>{service.title}</h3>
                  <p>{service.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Why Choose Us Section */}
        <section className="why-us-section">
          <h2 className="section-title">Why Choose Us?</h2>
          <div className="features-grid">
            {[
              "Real-time Train Tracking",
              "Secure Payment System",
              "24/7 Customer Support",
              "Easy Refund Process",
              "Multiple Payment Options",
              "Instant Booking Confirmation"
            ].map((feature, index) => (
              <div key={index} className="feature-item">
                <FaCheckCircle className="feature-icon" />
                <span>{feature}</span>
              </div>
            ))}
          </div>
        </section>

        {/* Team Section */}
        <section className="team-section">
          <h2 className="section-title">Meet Our Team</h2>
          <div className="row justify-content-center">
            <div className="col-md-4">
              <div className="team-card">
                <div className="team-img-container">
                  <img src="https://via.placeholder.com/300" alt="Priyanshi Joshi" className="team-img" />
                </div>
                <div className="team-info">
                  <h3>Priyanshi Joshi</h3>
                  <p className="designation">Full Stack Developer</p>
                  <p className="team-desc">
                    Passionate about creating seamless digital experiences for Indian Railways
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section className="contact-section">
          <h2 className="section-title">Get in Touch</h2>
          <div className="contact-grid">
            <div className="contact-item">
              <FaPhoneAlt className="contact-icon" />
              <h3>Phone</h3>
              <p>+91 9876543210</p>
            </div>
            <div className="contact-item">
              <FaEnvelope className="contact-icon" />
              <h3>Email</h3>
              <p>support@indianrailways.com</p>
            </div>
            <div className="contact-item">
              <FaMapMarkerAlt className="contact-icon" />
              <h3>Address</h3>
              <p>Rail Bhawan, New Delhi<br />India - 110001</p>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};

export default About;