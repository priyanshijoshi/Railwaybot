import React from 'react';
import PredictionForm from '../components/PredictionForm';
import './PredictionPage.css';  // Create this CSS file for styling

const PredictionPage = () => {
    return (
        <div className="prediction-page">
            <div className="prediction-header">
                <h1>Complaint Analysis</h1>
                <p>Enter your complaint text below for AI-powered categorization</p>
            </div>
            <PredictionForm />
        </div>
    );
};

export default PredictionPage;