import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FaTrain, FaMapMarkerAlt, FaCalendar, FaUser, FaHome } from 'react-icons/fa';
import { Link } from 'react-router-dom';

import '../styles/PNRStatus.css';

const PNRStatus = () => {
    const [pnrNumber, setPnrNumber] = useState('');
    const [pnrData, setPnrData] = useState(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const [recentSearches, setRecentSearches] = useState([]);

    useEffect(() => {
        // Load recent searches from localStorage
        const saved = localStorage.getItem('recentPNRSearches');
        if (saved) {
            setRecentSearches(JSON.parse(saved));
        }
    }, []);
    const saveSearch = (data) => {
        const newSearch = {
            pnr: data.pnrNumber,
            trainName: data.trainName,
            date: new Date().toISOString()
        };
        
        const updatedSearches = [
            newSearch,
            ...recentSearches.filter(search => search.pnr !== data.pnrNumber)
        ].slice(0, 5); // Keep only the 5 most recent searches
        
        setRecentSearches(updatedSearches);
        localStorage.setItem('recentPNRSearches', JSON.stringify(updatedSearches));
    };
    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        setError('');
        
        try {
            // First, check if PNR is valid
            if (!pnrNumber || pnrNumber.length !== 10) {
                throw new Error('Please enter a valid 10-digit PNR number');
            }
    
            console.log('Fetching details for PNR:', pnrNumber); // Debug log
    
            // Make the API call to RapidAPI
            const response = await fetch(`https://irctc-indian-railway-pnr-status.p.rapidapi.com/getPNRStatus/${pnrNumber}`, {
                method: 'GET',
                headers: {
                    'X-RapidAPI-Key': '933190beb3msh24ed615d465a271p1e256fjsn24317854e59f',
                    'X-RapidAPI-Host': 'irctc-indian-railway-pnr-status.p.rapidapi.com'
                }
            });
    
            // Log the raw response for debugging
            console.log('API Response Status:', response.status);
            const responseData = await response.json();
            console.log('API Response:', responseData);
    
            if (!response.ok) {
                throw new Error('Failed to fetch PNR status');
            }
    
            if (!responseData.success) {
                throw new Error(responseData.message || 'Unable to get PNR details');
            }
    
            const data = responseData.data;
            
            // Format the response data
            const formattedData = {
                pnrNumber: data.pnrNumber,
                trainNumber: data.trainNumber,
                trainName: data.trainName,
                sourceStation: data.sourceStation,
                destinationStation: data.destinationStation,
                boardingPoint: data.boardingPoint,
                dateOfJourney: data.dateOfJourney,
                journeyClass: data.journeyClass,
                chartStatus: data.chartStatus,
                passengers: data.passengerList || [],
                quota: data.quota,
                fare: data.ticketFare,
                bookingDate: data.bookingDate,
                arrivalDate: data.arrivalDate,
                distance: data.distance
            };
    
            setPnrData(formattedData);
            saveSearch(formattedData);
        } catch (err) {
            console.error('Error:', err);
            setError(err.message || 'Unable to fetch PNR status. Please try again.');
        } finally {
            setLoading(false);
        }
    };
    return (
        <div className="pnr-status-container">
            <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="pnr-form-container"
            >
                <div className="header-container">
                    <Link to="/" className="home-link">
                        <motion.div
                            whileHover={{ scale: 1.05 }}
                            whileTap={{ scale: 0.95 }}
                            className="home-button"
                        >
                            <FaHome /> Home
                        </motion.div>
                    </Link>
                    <h1>
                        <FaTrain className="icon-train" />
                        PNR Status Check
                    </h1>
                </div>

                {/* Recent Searches */}
                {recentSearches.length > 0 && (
                    <motion.div 
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="recent-searches"
                    >
                        <h3>Recent Searches</h3>
                        <div className="recent-searches-grid">
                            {recentSearches.map((search, index) => (
                                <motion.div 
                                    key={index}
                                    whileHover={{ scale: 1.02 }}
                                    className="recent-search-card"
                                    onClick={() => setPnrNumber(search.pnr)}
                                >
                                    <p>{search.trainName}</p>
                                    <p className="pnr-number">PNR: {search.pnr}</p>
                                    <small>{new Date(search.date).toLocaleDateString()}</small>
                                </motion.div>
                            ))}
                        </div>
                    </motion.div>
                )}

<form onSubmit={handleSubmit} className="pnr-form">
    <div className="input-group">
        <input
            type="text"
            value={pnrNumber}
            onChange={(e) => setPnrNumber(e.target.value.replace(/\D/g, ''))}
            placeholder="Enter 10-digit PNR Number"
            maxLength="10"
            pattern="\d{10}"
            required
            disabled={loading}
        />
        <motion.button 
            type="submit" 
            disabled={loading || pnrNumber.length !== 10}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
        >
            {loading ? (
                <div className="loader">Checking...</div>
            ) : (
                'Check Status'
            )}
        </motion.button>
    </div>
    {error && (
        <motion.div 
            className="error-message"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
        >
            {error}
        </motion.div>
       )}
</form>

               <AnimatePresence>
                {pnrData && (
                    <motion.div 
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -20 }}
                        className="pnr-details"
                    >
                        {/* Train Info Section */}
                        <motion.div 
                            className="train-info"
                            initial={{ x: -20 }}
                            animate={{ x: 0 }}
                        >
                            <h2>{pnrData.trainName} ({pnrData.trainNumber})</h2>
                            <div className="journey-details">
                                <div className="station-info">
                                    <FaMapMarkerAlt className="icon" />
                                    <p className="station">{pnrData.sourceStation} - {pnrData.boardingPoint}</p>
                                    <p className="label">From</p>
                                </div>
                                <div className="journey-line">
                                    <motion.div 
                                        className="train-progress"
                                        initial={{ width: 0 }}
                                        animate={{ width: '100%' }}
                                        transition={{ duration: 1 }}
                                    />
                                </div>
                                <div className="station-info">
                                    <FaMapMarkerAlt className="icon" />
                                    <p className="station">{pnrData.destinationStation}</p>
                                    <p className="label">To</p>
                                </div>
                            </div>
                            <div className="journey-info">
                                <div className="info-item">
                                    <FaCalendar className="icon" />
                                    <p>Journey Date: {pnrData.dateOfJourney}</p>
                                </div>
                                <div className="info-item">
                                    <p>Class: {pnrData.journeyClass}</p>
                                    <p>Quota: {pnrData.quota}</p>
                                </div>
                                <div className="info-item">
                                    <p>Distance: {pnrData.distance} KM</p>
                                    <p>Fare: ₹{pnrData.fare}</p>
                                </div>
                                <div className="info-item">
                                    <p>Booking Date: {pnrData.bookingDate}</p>
                                    <p>Arrival Date: {pnrData.arrivalDate}</p>
                                </div>
                            </div>
                        </motion.div>

                        {/* Passengers Section */}
                        {pnrData.passengers && pnrData.passengers.length > 0 && (
                            <motion.div 
                                className="passengers-info"
                                initial={{ opacity: 0 }}
                                animate={{ opacity: 1 }}
                                transition={{ delay: 0.3 }}
                            >
                                <h3>
                                    <FaUser className="icon" />
                                    Passenger Status
                                </h3>
                                <div className="passengers-grid">
                                    {pnrData.passengers.map((passenger, index) => (
                                        <motion.div 
                                            key={index}
                                            className="passenger-card"
                                            initial={{ scale: 0.9, opacity: 0 }}
                                            animate={{ scale: 1, opacity: 1 }}
                                            transition={{ delay: index * 0.1 }}
                                        >
                                            <p className="passenger-number">Passenger {index + 1}</p>
                                            <div className={`status ${passenger.bookingStatus?.toLowerCase()}`}>
                                                <p>Booking Status: {passenger.bookingStatus}</p>
                                                <p>Current Status: {passenger.currentStatus}</p>
                                            </div>
                                        </motion.div>
                                    ))}
                                </div>
                            </motion.div>
                        )}

                        {/* Chart Status */}
                        <motion.div 
                            className="chart-status"
                            initial={{ y: 20, opacity: 0 }}
                            animate={{ y: 0, opacity: 1 }}
                            transition={{ delay: 0.5 }}
                        >
                            <p>Chart Status: 
                                <span className={pnrData.chartStatus === "Chart Prepared" ? "prepared" : "not-prepared"}>
                                    {pnrData.chartStatus}
                                </span>
                            </p>
                        </motion.div>
                    </motion.div>
                )}
            </AnimatePresence>
        </motion.div>
    </div>
);
};
export default PNRStatus;