import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { FaTrain, FaSearch, FaHome, FaClock, FaMapMarkerAlt, FaCalendar } from 'react-icons/fa';
import { Link } from 'react-router-dom';
import '../styles/TrainSchedule.css';

const TrainSchedule = () => {
    const [trainNumber, setTrainNumber] = useState('');
    const [schedule, setSchedule] = useState(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const navigate = useNavigate();

    useEffect(() => {
        const token = localStorage.getItem('token');
        if (!token) {
            navigate('/login');
        }
    }, [navigate]);

    const handleSearch = async (e) => {
        e.preventDefault();
        setLoading(true);
        setError('');
    
        try {
            // Get today's date in YYYYMMDD format
            const today = new Date();
            const formattedDate = today.getFullYear() +
                String(today.getMonth() + 1).padStart(2, '0') +
                String(today.getDate()).padStart(2, '0');
    
            // Use only the real-time API endpoint
            const url = 'https://indian-railway-irctc.p.rapidapi.com/api/trains/v1/train/status';
            
            // Set up query parameters
            const params = new URLSearchParams({
                departure_date: formattedDate,
                isH5: 'true',
                client: 'web',
                train_number: trainNumber
            });
    
            const response = await fetch(`${url}?${params}`, {
                method: 'GET',
                headers: {
                    'x-rapidapi-key': '933190beb3msh24ed615d465a271p1e256fjsn24317854e59f',
                    'x-rapidapi-host': 'indian-railway-irctc.p.rapidapi.com',
                    'x-rapid-api': 'rapid-api-database'
                }
            });
    
            const data = await response.json();
            console.log('API Response:', data);

            // Check for successful response
            if (data.code === 200 && data.body) {
                const trainData = data.body;
                const transformedData = {
                    trainName: trainData.train_name || 'N/A',
                    trainNumber: trainNumber,
                    trainType: trainData.train_type || 'N/A',
                    runningDays: trainData.running_days || [],
                    source: trainData.source_station || 'N/A',
                    destination: trainData.destination_station || 'N/A',
                    stations: trainData.station_list?.map(station => ({
                        stationName: station.station_name,
                        arrivalTime: station.arrival_time,
                        departureTime: station.departure_time,
                        distance: station.distance_from_source,
                        platform: station.platform_number,
                        status: station.current_status
                    })) || [],
                    liveStatus: {
                        currentStation: trainData.current_station_name || 'N/A',
                        status: trainData.running_status || 'Information not available',
                        lastUpdated: new Date().toLocaleTimeString(),
                        delay: trainData.delay_info || 'No delay information'
                    }
                };
                setSchedule(transformedData);
            } else {
                setError(data.error || 'No schedule found for this train');
            }
        } catch (err) {
            console.error('Error details:', err);
            setError(err.message || 'Failed to fetch train details');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="train-schedule-container">
            <div className="header">
                <Link to="/" className="home-button">
                    <FaHome /> Home
                </Link>
                <h1><FaTrain /> Train Schedule & Live Status</h1>
            </div>

            <form onSubmit={handleSearch} className="search-form">
                <div className="input-group">
                    <input
                        type="text"
                        value={trainNumber}
                        onChange={(e) => setTrainNumber(e.target.value.replace(/\D/g, ''))}
                        placeholder="Enter Train Number (e.g., 12051)"
                        maxLength="5"
                        required
                    />
                    <button 
                        type="submit" 
                        disabled={loading || trainNumber.length !== 5}
                        className={loading ? 'loading' : ''}
                    >
                        {loading ? 'Searching...' : <><FaSearch /> Search</>}
                    </button>
                </div>
            </form>

            {error && (
                <div className="error-message">
                    <FaTrain className="error-icon" />
                    {error}
                </div>
            )}

            {schedule && (
                <div className="schedule-details">
                    <div className="train-info">
                        <h2>{schedule.trainName}</h2>
                        <p className="train-number">Train No: {schedule.trainNumber}</p>
                        
                        <div className="train-details">
                            <div className="detail-item">
                                <FaTrain className="detail-icon" />
                                <span>Type: {schedule.trainType}</span>
                            </div>
                            <div className="detail-item">
                                <FaCalendar className="detail-icon" />
                                <span>Running Days: {Array.isArray(schedule.runningDays) ? 
                                    schedule.runningDays.join(', ') : schedule.runningDays}</span>
                            </div>
                        </div>

                        <div className="route-info">
                            <p>From: {schedule.source}</p>
                            <p>To: {schedule.destination}</p>
                        </div>

                        {schedule.liveStatus && (
                            <div className="live-status">
                                <h3><FaClock /> Live Status</h3>
                                <div className="status-details">
                                    <p>Current Station: {schedule.liveStatus.currentStation}</p>
                                    <p>Status: {schedule.liveStatus.status}</p>
                                    <p>Delay: {schedule.liveStatus.delay}</p>
                                    <p>Last Updated: {schedule.liveStatus.lastUpdated}</p>
                                </div>
                            </div>
                        )}
                    </div>

                    {schedule.stations && schedule.stations.length > 0 && (
                        <div className="schedule-table">
                            <h3><FaMapMarkerAlt /> Complete Journey Schedule</h3>
                            <table>
                                <thead>
                                    <tr>
                                        <th>Station</th>
                                        <th>Arrival</th>
                                        <th>Departure</th>
                                        <th>Distance</th>
                                        <th>Platform</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {schedule.stations.map((station, index) => (
                                        <tr key={index} className={
                                            schedule.liveStatus?.currentStation === station.stationName 
                                            ? 'current-station' 
                                            : ''
                                        }>
                                            <td>{station.stationName}</td>
                                            <td>{station.arrivalTime || '-'}</td>
                                            <td>{station.departureTime || '-'}</td>
                                            <td>{station.distance ? `${station.distance} km` : '-'}</td>
                                            <td>{station.platform || '-'}</td>
                                            <td className={`status ${station.status?.toLowerCase() || ''}`}>
                                                {station.status || '-'}
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    )}
                </div>
            )}
        </div>
    );
};

export default TrainSchedule;