import React from "react";
import Chatbot from "../components/Chatbot";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";

const Complaint = () => {
  return (
    <div>
      <Navbar />
      <h1>File a Complaint</h1>
      <Chatbot />
      <Footer />
    </div>
  );
};

export default Complaint;
