import { createBrowserRouter } from 'react-router-dom';
import Home from './pages/Home';
import Login from './components/Login';
import Register from './components/Register';
import About from './pages/About';
import PNRStatus from './pages/PNRStatus';
import TrainBooking from './pages/TrainBooking';

const router = createBrowserRouter([
  {
    path: '/',
    element: <Home />,
  },
  {
    path: '/about',
    element: <About />,
  },
  {
    path: '/login',
    element: <Login />,
  },
  {
    path: '/register',
    element: <Register />,
  },
  {
    path: '/pnr-status',
    element: <PNRStatus />,
  },
  {
    path: '/book-tickets',
    element: <TrainBooking />,
  },
], {
  future: {
    v7_startTransition: true,
    v7_relativeSplatPath: true
  }
});

export default router;