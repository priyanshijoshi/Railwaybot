import React, { useEffect } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import Login from './components/Login';
import Register from './components/Register';
import About from "./pages/About";
import PNRStatus from './pages/PNRStatus';
import TrainSchedule from './pages/TrainSchedule';

import { testAllConnections } from './api/modelService';

function App() {
  useEffect(() => {
    const checkConnection = async () => {
      try {
        const result = await testAllConnections();
        console.log('Connection test results:', result);
      } catch (error) {
        console.error('Connection test error:', error);
      }
    };
    
    checkConnection();
  }, []);

  return (
  
    <Routes>
    <Route path="/" element={<Home />} />
    <Route path="/about" element={<About />} />
    <Route path="/login" element={<Login />} />
    <Route path="/register" element={<Register />} />
    <Route path="/pnr-status" element={<PNRStatus />} />
    <Route path="/train-schedule" element={<TrainSchedule />} />

  </Routes>

    
  );
}
export default App;