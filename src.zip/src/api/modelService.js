// Existing prediction function
export const predictComplaint = async (text, modelType = 'rf') => {
  // ... existing code ...
};

// Add these new functions



export const testAllConnections = async () => {
  try {
    const results = {
      mainApi: false,
      chatbotApi: false,
      pnrApi: false,
      bookingApi: false
    };
  
      // Test main API
      try {
        const mainResponse = await fetch('http://localhost:5001/');
        const mainData = await mainResponse.json();
        results.mainApi = true;
        console.log('Main API (5001):', mainData);
      } catch (error) {
        console.log('Main API connection failed:', error);
      }
  
      // Test chatbot API
      try {
        const chatbotResponse = await fetch('http://localhost:5002/');
        const chatbotData = await chatbotResponse.json();
        results.chatbotApi = true;
        console.log('Chatbot API (5002):', chatbotData);
      } catch (error) {
        console.log('Chatbot API connection failed:', error);
      }
  
      // Test PNR API
      try {
        const pnrResponse = await fetch('http://localhost:5003/api/health');
        const pnrData = await pnrResponse.json();
        results.pnrApi = true;
        console.log('PNR Status API (5003):', pnrData);
      } catch (error) {
        console.log('PNR API connection failed:', error);
        
      }
      
  } 
  catch (error) {
    console.error('Connection test failed:', error);
    return {
      error: error.message,
      status: 'Connection test failed'
    };
  }
};
export const getPNRStatus = async (pnr) => {
  try {
    const response = await fetch('http://localhost:5003/api/pnr-status', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ pnr })
    });
    return response.json();
  } catch (error) {
    throw error;
  }
};

  export const sendChatMessage = async (message) => {
    try {
        const response = await fetch('http://localhost:5002/api/chat', {  
            method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ message })
      });
      return response.json();
    } catch (error) {
      throw error;
    }
  };
  
  export const getComplaints = async () => {
    try {
      const response = await fetch('http://localhost:5001/api/complaints');
      return response.json();
    } catch (error) {
      throw error;
    }
  };
  export const searchTrains = async (fromStation, toStation, date) => {
    const response = await fetch(`http://localhost:5004/api/search-trains?from=${fromStation}&to=${toStation}&date=${date}`);
    return response.json();
};

export const checkAvailability = async (trainNumber, fromStation, toStation, date, classCode) => {
    const response = await fetch(`http://localhost:5004/api/check-availability?trainNumber=${trainNumber}&fromStation=${fromStation}&toStation=${toStation}&date=${date}&class=${classCode}`);
    return response.json();
};

export const getTrainSchedule = async (trainNumber) => {
  try {
      const response = await fetch(`http://localhost:5006/train-schedule?train_number=${trainNumber}`);
      
      if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.error || 'Failed to fetch train schedule');
      }

      return await response.json();
  } catch (error) {
      console.error('Train schedule error:', error);
      throw error;
  }
};



export const loginUser = async (email, password) => {
  try {
      const response = await fetch('http://localhost:5005/api/login', {
          method: 'POST',
          headers: {
              'Content-Type': 'application/json',
          },
          body: JSON.stringify({ email, password })
      });

      const data = await response.json();
      
      if (!response.ok) {
          throw new Error(data.error || 'Login failed');
      }

      return data;
  } catch (error) {
      console.error('Login error:', error);
      throw error;
  }
};

export const registerUser = async (email, password) => {
  try {
      const response = await fetch('http://localhost:5005/api/register', {
          method: 'POST',
          headers: {
              'Content-Type': 'application/json',
          },
          body: JSON.stringify({ email, password })
      });

      const data = await response.json();
      
      if (!response.ok) {
          throw new Error(data.error || 'Registration failed');
      }

      return data;
  } catch (error) {
      throw error;
  }
};