import React, { useState, useRef, useEffect } from 'react';
import '../styles/Chatbot.css';
import { FaRobot, FaPaperPlane, FaTrain, FaTimes } from 'react-icons/fa';

const Chatbot = ({ onClose }) => {
    const [messages, setMessages] = useState([
        {
            text: "Hello! I'm your Indian Railways Assistant. I can help you with:\n- PNR Status (e.g., 'Check PNR 1234567890')\n- Train Schedule (e.g., 'Show schedule for train 12345')\n- Live Status (e.g., 'Live status of train 12345')\n- Emergency Alerts\n- Nearby Services",
            isBot: true
        }
    ]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const messagesEndRef = useRef(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(scrollToBottom, [messages]);

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!input.trim()) return;

        const userMessage = { text: input, isBot: false };
        setMessages((prevMessages) => [...prevMessages, userMessage]);
        setInput('');
        setIsLoading(true);

        try {
            const response = await fetch('http://localhost:5002/chatbot', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ query: input })
            });

            const data = await response.json();
            const formattedResponse = formatResponse(data.response);

            const botMessage = { text: formattedResponse, isBot: true };
            setMessages((prevMessages) => [...prevMessages, botMessage]);
        } catch (error) {
            setMessages((prevMessages) => [...prevMessages, { text: 'Error fetching response.', isBot: true }]);
        }

        setIsLoading(false);
    };

    const formatResponse = (response) => {
        if (typeof response === 'string') {
            return response.replace(/\n/g, '<br/>'); // Formatting new lines for better readability
        } else if (typeof response === 'object') {
            return Object.entries(response)
                .map(([key, value]) => `<strong>${key}:</strong> ${value}`)
                .join('<br/>');
        }
        return response;
    };

    return (
        <div className="chatbot-container half-page">
            <div className="chat-header">
                <FaTrain /> Indian Railways Assistant
                <button className="close-btn" onClick={onClose}><FaTimes /></button>
            </div>
            <div className="chat-body">
                {messages.map((msg, index) => (
                    <div key={index} className={msg.isBot ? 'bot-message' : 'user-message'}>
                        <span dangerouslySetInnerHTML={{ __html: msg.text }} />
                    </div>
                ))}
                {isLoading && <div className="bot-message">Thinking...</div>}
                <div ref={messagesEndRef} />
            </div>
            <form onSubmit={handleSubmit} className="chat-input">
                <input
                    type="text"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder="Ask me about train schedules, PNR status, etc."
                />
                <button type="submit"><FaPaperPlane /></button>
            </form>
        </div>
    );
};

export default Chatbot;