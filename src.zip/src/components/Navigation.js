import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { FaSun, FaMoon, FaTrain } from "react-icons/fa";
import "../styles/Navigation.css";

function Navigation() {
  const location = useLocation();
  const [darkMode, setDarkMode] = useState(() => localStorage.getItem("darkMode") === "true");
  const [language, setLanguage] = useState(() => localStorage.getItem("language") || "EN");

  const translations = {
    EN: {
      home: "Home",
      about: "About",
      services: "Services",
      contact: "Contact",
      support: "Support Services",
      customers: "Existing Customers",
      track: "Track & Trace",
      booking: "Ticket Booking"
    },
    HI: {
      home: "होम",
      about: "हमारे बारे में",
      services: "सेवाएं",
      contact: "संपर्क",
      support: "सहायता सेवाएं",
      customers: "मौजूदा ग्राहक",
      track: "ट्रैक और ट्रेस",
      booking: "टिकट बुकिंग"
    }
  };

  useEffect(() => {
    // Apply dark mode on mount and when darkMode state changes
    document.body.classList.toggle("dark-mode", darkMode);
    localStorage.setItem("darkMode", darkMode);
  }, [darkMode]);

  useEffect(() => {
    // Save language preference
    localStorage.setItem("language", language);
  }, [language]);

  const toggleDarkMode = () => {
    setDarkMode(prev => !prev);
  };

  return (
    <nav className={`custom-navbar ${darkMode ? "navbar-dark" : "navbar-light"}`}>
      <div className="navbar-container">
        {/* Brand Logo */}
        <Link className="navbar-brand" to="/">
          <FaTrain className="brand-icon" />
          <span>Indian Railways</span>
        </Link>

        {/* Main Navigation */}
        <div className="nav-links">
          <Link 
            className={`nav-link ${location.pathname === "/" ? "active" : ""}`} 
            to="/"
          >
            {translations[language].home}
          </Link>
          <Link 
            className={`nav-link ${location.pathname === "/about" ? "active" : ""}`} 
            to="/about"
          >
            {translations[language].about}
          </Link>
          
          {/* Services Dropdown */}
          <div className="nav-dropdown">
            <button className="dropdown-trigger">
              {translations[language].services}
            </button>
            <div className="dropdown-content">
              <Link to="/support-services">{translations[language].support}</Link>
              <Link to="/track-trace">{translations[language].track}</Link>
              <Link to="/booking">{translations[language].booking}</Link>
            </div>
          </div>

          <Link 
            className={`nav-link ${location.pathname === "/contact" ? "active" : ""}`} 
            to="/contact"
          >
            {translations[language].contact}
          </Link>
        </div>

        {/* Controls */}
        <div className="nav-controls">
          <select 
            className="language-selector"
            value={language}
            onChange={(e) => setLanguage(e.target.value)}
          >
            <option value="EN">English</option>
            <option value="HI">हिंदी</option>
          </select>

          <button 
            className="theme-toggle"
            onClick={toggleDarkMode}
            aria-label="Toggle theme"
          >
            {darkMode ? <FaSun /> : <FaMoon />}
          </button>
        </div>
        <div className="nav-controls">
  <Link to="/login" className="nav-link">Login</Link>
  <Link to="/register" className="nav-link">Register</Link>
</div>

      </div>
    </nav>
  );
}

export default Navigation;