import React from "react";

const Footer = () => {
  return (
    <footer style={{ background: "#333", color: "white", textAlign: "center", padding: "10px", width: "100%", position: "fixed", bottom: "0" }}>
      <p>&copy; 2024 Complaint System</p>
    </footer>
  );
};

export default Footer;
