import React from "react";
import { Link } from "react-router-dom";

const Navbar = () => {
  return (
    <nav style={{ padding: "10px", background: "#333", color: "#fff" }}>
      <Link to="/" style={{ color: "white", marginRight: "10px" }}>Home</Link>
      <Link to="/complaint" style={{ color: "white", marginRight: "10px" }}>File Complaint</Link>
      <Link to="/login" style={{ color: "white" }}>Login</Link>
      <Link to="/pnr-status" className="nav-link">PNR Status</Link>
      <Link to="/Book-Tickets" className="nav-link">Train Booking</Link>

    </nav>
  );
};

export default Navbar;
