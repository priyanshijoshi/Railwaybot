import React, { useState } from 'react';
import { predictComplaint } from '../api/modelService';
import './PredictionForm.css';  // Create this CSS file for styling

const PredictionForm = () => {
    const [text, setText] = useState('');
    const [prediction, setPrediction] = useState(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        setError(null);
        
        try {
            const result = await predictComplaint(text);
            setPrediction(result);
        } catch (error) {
            setError('Failed to get prediction. Please try again.');
            console.error('Prediction error:', error);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="prediction-form-container">
            <form onSubmit={handleSubmit} className="prediction-form">
                <div className="form-group">
                    <label htmlFor="complaint-text">Enter your complaint:</label>
                    <textarea
                        id="complaint-text"
                        value={text}
                        onChange={(e) => setText(e.target.value)}
                        placeholder="Type your complaint here..."
                        rows="5"
                        required
                    />
                </div>

                <button 
                    type="submit" 
                    disabled={loading || !text.trim()}
                    className="submit-button"
                >
                    {loading ? 'Analyzing...' : 'Analyze Complaint'}
                </button>

                {error && <div className="error-message">{error}</div>}

                {prediction && (
                    <div className="prediction-result">
                        <h3>Analysis Result:</h3>
                        <p>Category: <span>{prediction.prediction}</span></p>
                        <p>Confidence: <span>{(prediction.probability * 100).toFixed(2)}%</span></p>
                    </div>
                )}
            </form>
        </div>
    );
};

export default PredictionForm;