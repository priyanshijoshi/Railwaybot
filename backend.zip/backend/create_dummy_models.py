import joblib
import os
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import LabelEncoder

# Create models directory if it doesn't exist
if not os.path.exists('models'):
    os.makedirs('models')

# Sample complaints and categories
sample_complaints = [
    "Train was delayed",
    "AC not working",
    "Food quality poor",
    "Staff behavior rude",
    "Washroom dirty"
]

sample_categories = [
    "Delay",
    "Amenities",
    "Food",
    "Staff",
    "Cleanliness"
]

# Create and save TF-IDF vectorizer
vectorizer = TfidfVectorizer()
vectorizer.fit(sample_complaints)
joblib.dump(vectorizer, 'models/tfidf_vectorizer.pkl')

# Create and save Label Encoder
label_encoder = LabelEncoder()
label_encoder.fit(sample_categories)
joblib.dump(label_encoder, 'models/label_encoder.pkl')

# Create and save Random Forest model
rf_model = RandomForestClassifier(n_estimators=10)
X = vectorizer.transform(sample_complaints)
y = label_encoder.transform(sample_categories)
rf_model.fit(X, y)
joblib.dump(rf_model, 'models/random_forest_model.pkl')

print("Dummy models created successfully!")