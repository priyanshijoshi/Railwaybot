from flask import Flask, request, jsonify
from flask_cors import CORS
import pickle
import requests
from datetime import datetime
import torch
from transformers import BertTokenizer, BertForSequenceClassification
import re
import json
from models.query import db, Query  # Import db and Query from models.Query

app = Flask(__name__)
CORS(app, resources={
    r"/*": {
        "origins": ["http://localhost:3000"],
        "methods": ["GET", "POST", "OPTIONS"],
        "allow_headers": ["Content-Type", "Authorization"]
    }
})
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:Root%40123@localhost/test_db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)

# Create the database tables
with app.app_context():
    db.create_all()

# Load BERT model and tokenizer
tokenizer = BertTokenizer.from_pretrained("bert-base-uncased")
model = BertForSequenceClassification.from_pretrained("bert-base-uncased", num_labels=4)
device = "cuda" if torch.cuda.is_available() else "cpu"
model.to(device)

# Load your trained model
try:
    with open('trained_model.pkl', 'rb') as f:
        trained_model = pickle.load(f)
except:
    print("No trained model found. Using default responses.")

RAPIDAPI_KEY = "933190beb3msh24ed615d465a271p1e256fjsn24317854e59f"
RAPIDAPI_HOST = "indian-railway-irctc.p.rapidapi.com"
PNR_API_HOST = "irctc-indian-railway-pnr-status.p.rapidapi.com"

def extract_numbers(text):
    return re.findall(r'\d+', text)

def get_pnr_status(pnr):
    url = "https://irctc-indian-railway-pnr-status.p.rapidapi.com/getPNRStatus/8330136061"
    headers = {
        "x-rapidapi-key": "39fe572d3dmshaaccfee6779e164p128beajsn5979f99efbe8",
        "x-rapidapi-host": "irctc-indian-railway-pnr-status.p.rapidapi.com"
    }
    response = requests.get(url, params={"pnrNumber": pnr}, headers=headers)
    
    return response.json()

def get_train_schedule(train_number):
    url = "https://irctc1.p.rapidapi.com/api/v1/getTrainSchedule"
    headers= {
        'x-rapidapi-key': '39fe572d3dmshaaccfee6779e164p128beajsn5979f99efbe8',
        'x-rapidapi-host': 'irctc1.p.rapidapi.com'
    }
    response = requests.get(url, headers=headers, params={"trainNo": train_number})
    print(f"Train Schedule API Response: {response.json()}")  # Debugging line
    return response.json()

def get_live_status(train_number):
    url = "https://irctc1.p.rapidapi.com/api/v1/liveTrainStatus"
    headers = {
        "X-RapidAPI-Key": "39fe572d3dmshaaccfee6779e164p128beajsn5979f99efbe8",
        "X-RapidAPI-Host": 'irctc1.p.rapidapi.com'
    }
    response = requests.get(url, headers=headers, params={"trainNo": train_number, "startDay": 1})
    print(f"Live Status API Response: {response.json()}")  # Debugging line
    return response.json()

@app.route('/')
def home():
    return jsonify({
        "message": "PNR Status API is running",
        "status": "active"
    })

@app.route('/api/health')
def health_check():
    return jsonify({
        "status": "healthy",
        "service": "pnr-status-api"
    })

@app.route('/api/train_schedule/<train_number>')
def train_schedule(train_number):
    response = get_train_schedule(train_number)
    
    # JSON Formatting
    formatted_output = json.dumps(response.get('data', response.get('message', 'Unable to fetch schedule')), indent=4)
    
    return jsonify({
        "train_number": train_number,
        "schedule": json.loads(formatted_output)  # Convert formatted JSON back to dictionary
    })

@app.route('/api/live_status/<train_number>')
def live_status(train_number):
    response = get_live_status(train_number)
    
    # JSON Formatting
    formatted_output = json.dumps(response.get('data', response.get('message', 'Unable to fetch live status')), indent=4)
    
    return jsonify({
        "train_number": train_number,
        "live_status": json.loads(formatted_output)  # Convert formatted JSON back to dictionary
    })

@app.route('/chatbot', methods=['POST'])
def chatbot():
    try:
        user_query = request.json['query'].lower()
        
        # Extract numbers from query
        numbers = extract_numbers(user_query)
        
        # PNR Status Check
        if "pnr" in user_query and numbers:
            pnr = numbers[0]
            response = get_pnr_status(pnr)
            response_text = f"PNR Status for {pnr}: {response.get('data', 'Unable to fetch PNR status')}"
        
        # Train Schedule Check
        elif any(word in user_query for word in ["schedule", "time", "timing"]) and numbers:
            train_number = numbers[0]
            response = get_train_schedule(train_number)
            schedule = response.get('data', response.get('message', 'Unable to fetch schedule'))
            if isinstance(schedule, dict):
                formatted_schedule = "\n".join([f"{key}: {value}" for key, value in schedule.items()])
            else:
                formatted_schedule = schedule
            response_text = f"Train Schedule for {train_number}:\n{formatted_schedule}"
        
        # Live Status Check
        elif "live" in user_query and "status" in user_query and numbers:
            train_number = numbers[0]
            response = get_live_status(train_number)
            live_status = response.get('data', response.get('message', 'Unable to fetch live status'))
            if isinstance(live_status, dict):
                formatted_live_status = "\n".join([f"{key}: {value}" for key, value in live_status.items()])
            else:
                formatted_live_status = live_status
            response_text = f"Live Status for {train_number}:\n{formatted_live_status}"
        
        # Emergency Alerts
        elif "emergency" in user_query or "alert" in user_query:
            response_text = "Emergency Helpline: 139 (24x7)\nRailway Protection Force: 1322\nAmbulance: 108"
        
        # Nearby Services
        elif "nearby" in user_query:
            if "hotel" in user_query:
                response_text = "To find nearby hotels, please share your current station name or use our mobile app."
            elif "taxi" in user_query or "cab" in user_query:
                response_text = "For taxi services, you can use our partner apps or call railway taxi service at station."
            elif "metro" in user_query:
                response_text = "Please share your city name to get metro station information."
        
        # Use BERT model for general queries
        else:
            inputs = tokenizer(user_query, return_tensors="pt", truncation=True, max_length=128)
            inputs = {k: v.to(device) for k, v in inputs.items()}
            with torch.no_grad():
                outputs = model(**inputs)
                prediction = torch.argmax(outputs.logits, dim=1)
            
            # Map prediction to response
            responses = {
                0: "I can help you with train schedules, PNR status, and live train status.",
                1: "For booking related queries, please visit IRCTC website.",
                2: "For emergency assistance, please call 139.",
                3: "Please provide more specific information about your query."
            }
            
            response_text = responses[prediction.item()]

        # Save the query and response to the database
        new_query = Query(user_query=user_query, response=response_text)
        db.session.add(new_query)
        db.session.commit()

        return jsonify({"response": response_text})

    except Exception as e:
        return jsonify({"response": f"I apologize, but I encountered an error: {str(e)}"})

if __name__ == '__main__':
    app.run(port=5002, debug=True)