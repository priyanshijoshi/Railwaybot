import pandas as pd
import numpy as np

# Create sample complaints data
complaints_data = {
    'Complaint_Text': [
        "Train was delayed by 2 hours without any information",
        "The AC was not working in my compartment",
        "Booking system was down during tatkal hours",
        "Food quality was very poor in the train",
        "Staff behavior was very rude",
        "Washroom was not clean and maintained",
        "Wrong seat was allocated to me",
        "Platform was not announced properly",
        "Train schedule was changed without notification",
        "Overcharging for food items in train",
        "No water supply in coaches",
        "Security concern during night journey",
        "Ticket refund not processed yet",
        "Reserved seat was occupied by someone else",
        "Missing luggage complaint",
        "No proper lighting in coach",
        "Emergency chain pull not working",
        "Incorrect PNR status shown",
        "Bedroll quality was poor",
        "No wheelchair assistance provided"
    ],
    'Category': [
        "Delay",
        "Amenities",
        "Booking",
        "Food",
        "Staff",
        "Cleanliness",
        "Booking",
        "Communication",
        "Schedule",
        "Food",
        "Amenities",
        "Security",
        "Refund",
        "Seat",
        "Security",
        "Amenities",
        "Safety",
        "Technical",
        "Amenities",
        "Assistance"
    ]
}

# Create DataFrame
df = pd.DataFrame(complaints_data)

# Save to CSV
df.to_csv('complaints_dataset.csv', index=False)
print("Dataset created successfully!")

# Display first few rows
print("\nFirst few rows of the dataset:")
print(df.head())

# Display dataset info
print("\nDataset Info:")
print(df.info())