from flask import Flask, request, jsonify
from flask_cors import CORS
from models.database import db, User, ScheduleView
import requests
import jwt
from datetime import datetime
from functools import wraps  # Add this import for @wraps
import os
from flask import jsonify

app = Flask(__name__)
# Configure CORS properly
CORS(app, resources={
    r"/*": {
        "origins": ["http://localhost:3000"],
        "methods": ["GET", "POST", "OPTIONS"],
        "allow_headers": ["Content-Type", "Authorization"]
    }
})

app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:Root%40123@localhost/test_db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'your-secret-key-here'  # Add this line

db.init_app(app)

def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.headers.get('Authorization')
        if not token:
            return jsonify({'message': 'Token is missing'}), 401
        try:
            data = jwt.decode(token.split()[1], app.config['SECRET_KEY'], algorithms=["HS256"])
            current_user = User.query.filter_by(id=data['user_id']).first()
        except:
            return jsonify({'message': 'Token is invalid'}), 401
        return f(current_user, *args, **kwargs)
    return decorated

@app.route('/')
def home():
    return jsonify({
        "message": "Train Schedule API is running",
        "status": "active",
        "version": "1.0"
    })

@app.route('/api/health')
def health_check():
    return jsonify({
        "status": "healthy",
        "service": "train-schedule-api",
        "timestamp": datetime.now().isoformat()
    })@app.route('/train-schedule', methods=['GET'])
@token_required
def get_train_schedule(current_user):
    train_number = request.args.get('train_number')
    if not train_number:
        return jsonify({'error': 'Train number is required'}), 400
    
    # Updated URL for train search
    url = "https://indian-railway-irctc.p.rapidapi.com/api/v1/searchTrain"
    
    querystring = {
        "query": train_number
    }
    
    headers = {
        "X-RapidAPI-Key": "933190beb3msh24ed615d465a271p1e256fjsn24317854e59f",
        "X-RapidAPI-Host": "indian-railway-irctc.p.rapidapi.com"
    }

    try:
        # Record the view
        schedule_view = ScheduleView(
            user_id=current_user.id,
            train_number=train_number,
            timestamp=datetime.now()
        )
        db.session.add(schedule_view)
        db.session.commit()

        # First get train details
        response = requests.get(url, headers=headers, params=querystring)
        print(f"Train Search Response: {response.text}")  # Debug log
        
        if response.status_code == 200:
            train_data = response.json()
            
            if train_data.get('data') and len(train_data['data']) > 0:
                train_info = train_data['data'][0]  # Get first matching train
                
                # Now get live status
                status_url = "https://indian-railway-irctc.p.rapidapi.com/api/v1/liveTrainStatus"
                status_params = {"trainNo": train_number}
                
                status_response = requests.get(status_url, headers=headers, params=status_params)
                print(f"Status Response: {status_response.text}")  # Debug log
                
                status_data = status_response.json() if status_response.status_code == 200 else None

                # Combine both responses
                transformed_data = {
                    'success': True,
                    'data': {
                        'trainName': train_info.get('name', ''),
                        'trainNumber': train_number,
                        'trainType': train_info.get('train_type', ''),
                        'runningDays': train_info.get('days', []),
                        'source': train_info.get('train_from', ''),
                        'destination': train_info.get('train_to', ''),
                        'departureTime': train_info.get('departure_time', ''),
                        'arrivalTime': train_info.get('arrival_time', ''),
                        'duration': train_info.get('duration', ''),
                        'stations': train_info.get('route', []),
                        'liveStatus': {
                            'currentStation': status_data['data']['current_station_name'] if status_data and status_data.get('data') else 'Fetching...',
                            'status': status_data['data']['current_status'] if status_data and status_data.get('data') else 'Fetching status...',
                            'lastUpdated': datetime.now().strftime('%I:%M %p'),
                            'delay': status_data['data']['delay'] if status_data and status_data.get('data') else 'On time'
                        }
                    }
                }
                return jsonify(transformed_data)
            else:
                return jsonify({
                    'success': False,
                    'error': 'Train not found'
                }), 404

        else:
            return jsonify({
                'success': False,
                'error': 'Failed to fetch train details',
                'status_code': response.status_code
            }), response.status_code

    except Exception as e:
        print(f"Error: {str(e)}")  # Debug log
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500
if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(port=5006, debug=True)