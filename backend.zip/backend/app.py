from flask import Flask, request, jsonify
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import joblib
import tensorflow as tf
import numpy as np
from tensorflow.keras.preprocessing.sequence import pad_sequences
import openai
import os

# Initialize Flask app
app = Flask(__name__)
CORS(app, resources={r"/api/*": {"origins": "http://localhost:3000"}})
# Database configuration
try:
    app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:Root@123@localhost/test_db'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    
    # Initialize database
    db = SQLAlchemy(app)
    print("Database connection successful!")
except Exception as e:
    print(f"Database connection error: {e}")


# Initialize database
db = SQLAlchemy(app)

# Define MODEL_PATH
MODEL_PATH = os.path.join(os.path.dirname(__file__), 'models')

# Configure OpenAI
openai.api_key = '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'

# Complaint Model
class Complaint(db.Model):
    __tablename__ = 'complaints'
    
    id = db.Column(db.String(20), primary_key=True)
    message = db.Column(db.Text, nullable=False)
    category = db.Column(db.String(50), nullable=False)
    response = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(20), default='registered')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

# Load models function
def load_models():
    try:
        model_files = {
            'random_forest_model.pkl': None,
            'tfidf_vectorizer.pkl': None,
            'lstm_model.h5': None,
            'tokenizer.pkl': None,
            'label_encoder.pkl': None
        }

        for file_name in model_files.keys():
            file_path = os.path.join(MODEL_PATH, file_name)
            if not os.path.exists(file_path):
                print(f"Warning: {file_name} not found in {MODEL_PATH}")
                continue
            
            if file_name.endswith('.h5'):
                model_files[file_name] = tf.keras.models.load_model(file_path)
            else:
                model_files[file_name] = joblib.load(file_path)

        return {
            'rf_model': model_files['random_forest_model.pkl'],
            'tfidf_vectorizer': model_files['tfidf_vectorizer.pkl'],
            'lstm_model': model_files['lstm_model.h5'],
            'tokenizer': model_files['tokenizer.pkl'],
            'label_encoder': model_files['label_encoder.pkl']
        }
    except Exception as e:
        print(f"Error loading models: {e}")
        return None

# Routes
@app.route('/')
def home():
    return jsonify({"message": "API is running"})

@app.route('/api/complaints', methods=['GET'])
def get_all_complaints():
    try:
        complaints = Complaint.query.order_by(Complaint.created_at.desc()).all()
        return jsonify([{
            'id': c.id,
            'message': c.message,
            'category': c.category,
            'response': c.response,
            'status': c.status,
            'created_at': c.created_at.isoformat()
        } for c in complaints])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/complaint/<complaint_id>', methods=['GET'])
def get_complaint(complaint_id):
    try:
        complaint = Complaint.query.get_or_404(complaint_id)
        return jsonify({
            'id': complaint.id,
            'message': complaint.message,
            'category': complaint.category,
            'response': complaint.response,
            'status': complaint.status,
            'created_at': complaint.created_at.isoformat()
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Main execution
if __name__ == '__main__':
    # Create models directory if it doesn't exist
    os.makedirs(MODEL_PATH, exist_ok=True)
    
    # Create database tables
    with app.app_context():
        try:
            db.create_all()
            print("Database tables created successfully!")
        except Exception as e:
            print(f"Error creating database tables: {e}")
    
    # Load models
    models = load_models()
    if not models:
        print("Warning: Some models failed to load. Basic chat functionality will still work.")
    
    # Run the app
    app.run(port=5001, debug=True)