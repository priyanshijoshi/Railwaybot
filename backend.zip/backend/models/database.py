from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

# Initialize SQLAlchemy with None to avoid circular imports
db = SQLAlchemy()

class Complaint(db.Model):
    __tablename__ = 'complaints'
    
    id = db.Column(db.String(20), primary_key=True)
    message = db.Column(db.Text, nullable=False)
    category = db.Column(db.String(50), nullable=False)
    response = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(20), default='registered')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def __init__(self, id, message, category, response, status='registered'):
        self.id = id
        self.message = message
        self.category = category
        self.response = response
        self.status = status
class PNRStatus(db.Model):
    __tablename__ = 'pnr_status'
    
    id = db.Column(db.Integer, primary_key=True)
    pnr_number = db.Column(db.String(10), nullable=False)
    train_number = db.Column(db.String(10), nullable=False)
    train_name = db.Column(db.String(100), nullable=False)
    boarding_point = db.Column(db.String(100), nullable=False)
    destination = db.Column(db.String(100), nullable=False)
    date_of_journey = db.Column(db.String(10), nullable=False)
    chart_status = db.Column(db.String(20), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationship with Passenger model
    passengers = db.relationship('Passenger', backref='pnr_status', lazy=True)

    def __init__(self, pnr_number, train_number, train_name, boarding_point, 
                 destination, date_of_journey, chart_status):
        self.pnr_number = pnr_number
        self.train_number = train_number
        self.train_name = train_name
        self.boarding_point = boarding_point
        self.destination = destination
        self.date_of_journey = date_of_journey
        self.chart_status = chart_status

class Passenger(db.Model):
    __tablename__ = 'passengers'
    
    id = db.Column(db.Integer, primary_key=True)
    pnr_status_id = db.Column(db.Integer, db.ForeignKey('pnr_status.id'), nullable=False)
    booking_status = db.Column(db.String(10), nullable=False)
    current_status = db.Column(db.String(20), nullable=False)
    seat_number = db.Column(db.String(20))
    coach_number = db.Column(db.String(10))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def __init__(self, pnr_status_id, booking_status, current_status, 
                 seat_number=None, coach_number=None):
        self.pnr_status_id = pnr_status_id
        self.booking_status = booking_status
        self.current_status = current_status
        self.seat_number = seat_number
        self.coach_number = coach_number
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    schedule_views = db.relationship('ScheduleView', backref='user', lazy=True)

class ScheduleView(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    train_number = db.Column(db.String(10), nullable=False)
    viewed_at = db.Column(db.DateTime, default=datetime.utcnow) 