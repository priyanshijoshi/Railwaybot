import pandas as pd
from sklearn.preprocessing import LabelEncoder
import numpy as np
import re
import string
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.ensemble import RandomForestClassifier
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, LSTM, Dense, Dropout, SpatialDropout1D
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
import joblib
import os

# Create models directory if it doesn't exist
if not os.path.exists('models'):
    os.makedirs('models')

# Load dataset
print("Loading dataset...")
df = pd.read_csv("complaints_dataset.csv")
print(f"Dataset loaded with {len(df)} rows")

# Text Preprocessing
def clean_text(text):
    text = str(text).lower()
    text = re.sub(f"[{string.punctuation}]", "", text)
    text = re.sub("\d+", "", text)
    return text

print("Preprocessing text data...")
X = df['Complaint_Text'].apply(clean_text)
y = df['Category']

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# TF-IDF Vectorization
print("Training TF-IDF vectorizer...")
vectorizer = TfidfVectorizer(max_features=5000)
X_train_tfidf = vectorizer.fit_transform(X_train)
X_test_tfidf = vectorizer.transform(X_test)

# Train Random Forest
print("Training Random Forest model...")
rf_model = RandomForestClassifier(n_estimators=100, random_state=42)
rf_model.fit(X_train_tfidf, y_train)

# Evaluate Random Forest
rf_accuracy = rf_model.score(X_test_tfidf, y_test)
print(f"Random Forest Accuracy: {rf_accuracy:.2f}")

# Prepare data for LSTM
print("Preparing data for LSTM...")
tokenizer = Tokenizer(num_words=5000, oov_token="<OOV>")
tokenizer.fit_on_texts(X_train)

X_train_seq = tokenizer.texts_to_sequences(X_train)
X_test_seq = tokenizer.texts_to_sequences(X_test)

max_len = 100
X_train_pad = pad_sequences(X_train_seq, maxlen=max_len, padding='post')
X_test_pad = pad_sequences(X_test_seq, maxlen=max_len, padding='post')

# Encode labels
label_encoder = LabelEncoder()
y_train_encoded = label_encoder.fit_transform(y_train)
y_test_encoded = label_encoder.transform(y_test)

# LSTM Model
print("Training LSTM model...")
model = Sequential([
    Embedding(5000, 32, input_length=max_len),
    SpatialDropout1D(0.2),
    LSTM(64, dropout=0.2, recurrent_dropout=0.2),
    Dense(32, activation='relu'),
    Dense(len(label_encoder.classes_), activation='softmax')
])

model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])

# Train LSTM
model.fit(
    X_train_pad, y_train_encoded,
    epochs=5,
    batch_size=32,
    validation_data=(X_test_pad, y_test_encoded)
)

# Save models
print("Saving models...")
MODEL_PATH = 'models/'

# Save Random Forest model and vectorizer
joblib.dump(rf_model, os.path.join(MODEL_PATH, 'random_forest_model.pkl'))
joblib.dump(vectorizer, os.path.join(MODEL_PATH, 'tfidf_vectorizer.pkl'))

# Save LSTM model
model.save(os.path.join(MODEL_PATH, 'lstm_model.h5'))

# Save tokenizer and label encoder
joblib.dump(tokenizer, os.path.join(MODEL_PATH, 'tokenizer.pkl'))
joblib.dump(label_encoder, os.path.join(MODEL_PATH, 'label_encoder.pkl'))

print("All models saved successfully!")