import torch
import numpy as np
from transformers import BertTokenizer, BertForSequenceClassification, Trainer, TrainingArguments
from datasets import Dataset
import pandas as pd
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"Using device: {device}")

# Set random seed for reproducibility
torch.manual_seed(42)
if torch.cuda.is_available():
    torch.cuda.manual_seed_all(42)

# Define categories
CATEGORIES = {
    0: "PNR_STATUS",
    1: "TRAIN_SCHEDULE",
    2: "LIVE_STATUS",
    3: "EMERGENCY",
    4: "SERVICES",
    5: "STATION_INFO"
}

# Comprehensive railway dataset
railway_data = {
    'text': [
        # PNR Status Queries (Category 0)
        "What is the PNR status of 1234567890?",
        "Check PNR 1234567890",
        "Show my booking status for PNR 1234567890",
        "Is my ticket confirmed for PNR 1234567890?",
        "PNR status check 1234567890",
        "Ticket confirmation for 1234567890",
        "View PNR details 1234567890",
        "Current status of PNR 1234567890",
        
        # Train Schedule Queries (Category 1)
        "What is the schedule of train 19303?",
        "When does train 12345 arrive?",
        "Show timings for Rajdhani Express",
        "What time does train 19303 reach Delhi?",
        "Train 12345 departure time",
        "Schedule for Shatabdi Express",
        "What are the stops for train 19303?",
        "Running days of train 12345",
        
        # Live Status Queries (Category 2)
        "Show live status of train 12345",
        "Where is train 19303 now?",
        "Is train 12345 running on time?",
        "Current location of Rajdhani Express",
        "Track train 19303",
        "Live running status 12345",
        "How much delay in train 19303?",
        "Real-time location of train 12345",
        
        # Emergency Queries (Category 3)
        "Emergency helpline number",
        "Medical emergency in train",
        "Security help needed",
        "Report theft in train",
        "Contact RPF",
        "Train stopped unexpectedly",
        "Emergency brake pulled",
        "Need immediate medical assistance",
        
        # Service Queries (Category 4)
        "Food ordering in train",
        "Book wheelchair assistance",
        "Clean my coach",
        "AC not working in B3 coach",
        "Water not available",
        "Need blanket",
        "How to order food in train?",
        "Catering services available?",
        
        # Station Information (Category 5)
        "Platform number for train 12345",
        "Parking at New Delhi station",
        "Nearest metro to station",
        "Taxi booking at station",
        "Available hotels near station",
        "Luggage storage facility",
        "Waiting room availability",
        "Station amenities"
    ],
    'label': [
        # Labels corresponding to each query above
        0, 0, 0, 0, 0, 0, 0, 0,  # PNR Status
        1, 1, 1, 1, 1, 1, 1, 1,  # Train Schedule
        2, 2, 2, 2, 2, 2, 2, 2,  # Live Status
        3, 3, 3, 3, 3, 3, 3, 3,  # Emergency
        4, 4, 4, 4, 4, 4, 4, 4,  # Services
        5, 5, 5, 5, 5, 5, 5, 5   # Station Info
    ]
}

# Convert to DataFrame
df = pd.DataFrame(railway_data)

# Create Dataset object
dataset = Dataset.from_pandas(df)

# Split dataset
train_test = dataset.train_test_split(test_size=0.2)
train_dataset = train_test['train']
test_dataset = train_test['test']

# Initialize tokenizer and model
tokenizer = BertTokenizer.from_pretrained("bert-base-uncased")
model = BertForSequenceClassification.from_pretrained(
    "bert-base-uncased", 
    num_labels=len(CATEGORIES)
)

# Tokenize function
def tokenize_function(examples):
    return tokenizer(
        examples["text"],
        padding="max_length",
        truncation=True,
        max_length=128
    )

# Tokenize datasets
train_dataset = train_dataset.map(tokenize_function, batched=True)
test_dataset = test_dataset.map(tokenize_function, batched=True)

# Set format for pytorch
train_dataset.set_format('torch', columns=['input_ids', 'attention_mask', 'label'])
test_dataset.set_format('torch', columns=['input_ids', 'attention_mask', 'label'])

# Training arguments
training_args = TrainingArguments(
    output_dir="./railway_chatbot_model",
    num_train_epochs=3,
    per_device_train_batch_size=16,
    per_device_eval_batch_size=16,
    warmup_steps=500,
    weight_decay=0.01,
    logging_dir="./logs",
    logging_steps=10,
    evaluation_strategy="epoch",
    save_strategy="epoch",
    load_best_model_at_end=True,
)

# Initialize Trainer
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=train_dataset,
    eval_dataset=test_dataset,
)

# Train the model
trainer.train()

# Save the model and tokenizer
model.save_pretrained("./cleaned_complaints_dataset")
tokenizer.save_pretrained("./cleaned_complaints_dataset")

# Save categories mapping
import json
with open('./railway_chatbot_model/categories.json', 'w') as f:
    json.dump(CATEGORIES, f)

print("Training completed and model saved!")