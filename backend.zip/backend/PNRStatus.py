from flask import Flask, request, jsonify
from flask_cors import CORS
from datetime import datetime
from models.database import db, PNRStatus, Passenger
from flask_sqlalchemy import SQLAlchemy
import requests

app = Flask(__name__)
CORS(app, resources={
    r"/*": {
        "origins": ["http://localhost:3000"],
        "methods": ["POST", "GET", "OPTIONS"],
        "allow_headers": ["Content-Type", "Accept"]
    }
})
# Fix the database connection string
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:Root%40123@localhost/test_db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False


# Initialize SQLAlchemy
db = SQLAlchemy(app)

class PNRStatus(db.Model):
    __tablename__ = 'pnr_status'
    
    id = db.Column(db.Integer, primary_key=True)
    pnr_number = db.Column(db.String(10), nullable=False)
    train_number = db.Column(db.String(10), nullable=False)
    train_name = db.Column(db.String(100), nullable=False)
    boarding_point = db.Column(db.String(100), nullable=False)
    destination = db.Column(db.String(100), nullable=False)
    date_of_journey = db.Column(db.String(10), nullable=False)
    chart_status = db.Column(db.String(20), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Passenger(db.Model):
    __tablename__ = 'passengers'
    
    id = db.Column(db.Integer, primary_key=True)
    pnr_status_id = db.Column(db.Integer, db.ForeignKey('pnr_status.id'), nullable=False)
    booking_status = db.Column(db.String(10), nullable=False)
    current_status = db.Column(db.String(20), nullable=False)

@app.route('/')
def home():
    return jsonify({
        "message": "PNR Status API is running",
        "status": "active"
    })

@app.route('/api/health')
def health_check():
    return jsonify({
        "status": "healthy",
        "service": "pnr-status-api"
    })


@app.route('/api/pnr-status', methods=['POST'])
def get_pnr_status():
    try:
        data = request.get_json()
        pnr_number = data.get('pnr')

        if not pnr_number:
            return jsonify({"error": "PNR number is required"}), 400

        url = f"https://irctc-indian-railway-pnr-status.p.rapidapi.com/getPNRStatus/{8330136061}"
        headers = {
            "x-rapidapi-key": "933190beb3msh24ed615d465a271p1e256fjsn24317854e59f",
            "x-rapidapi-host": "irctc-indian-railway-pnr-status.p.rapidapi.com"
        }
        response = requests.get(url, params={"pnrNumber": pnr_number}, headers=headers)
        
        if response.status_code != 200:
            return jsonify({"error": f"API Error: {response.text}"}), response.status_code
            
        return response.json()  # Return the raw API response

    except Exception as e:
        print(f"Error: {e}")
        return jsonify({"error": str(e)}), 500
    
if __name__ == '__main__':
    with app.app_context():
        try:
            # Test database connection first
            db.engine.connect()
            print("Database connection successful!")
            
            # Create tables
            db.create_all()
            print("Database tables created successfully!")
        except Exception as e:
            print(f"Database error: {e}")
            print("\nPlease check:")
            print("1. Is XAMPP MySQL running?")
            print("2. Is the password correct? (Root@123)")
            print("3. Does the database 'test_db' exist?")
            print("\nTrying to create database if it doesn't exist...")
            
            try:
                # Try to create database
                engine = db.create_engine('mysql+pymysql://root:Root%40123@localhost/')
                conn = engine.connect()
                conn.execute("CREATE DATABASE IF NOT EXISTS test_db")
                conn.close()
                print("Database 'test_db' created successfully!")
                
                # Try creating tables again
                db.create_all()
                print("Tables created successfully!")
            except Exception as create_error:
                print(f"Failed to create database: {create_error}")
                print("\nPlease ensure MySQL is running and credentials are correct.")
    
    app.run(debug=True, port=5003)