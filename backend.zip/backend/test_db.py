from flask import Flask
from models.database import db, Complaint
from datetime import datetime

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:password123@localhost/test_db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

def test_connection():
    try:
        with app.app_context():
            # Try to create tables
            db.create_all()
            
            # Try to add a test complaint
            test_complaint = Complaint(
                id='TEST123',
                message='Test complaint',
                category='Test',
                response='Test response',
                status='registered'
            )
            db.session.add(test_complaint)
            db.session.commit()
            
            # Try to query the complaint
            complaint = Complaint.query.get('TEST123')
            print("Test complaint retrieved:", complaint.message)
            
            # Clean up test data
            db.session.delete(complaint)
            db.session.commit()
            
        print("Database connection successful!")
        return True
    except Exception as e:
        print(f"Database connection failed: {e}")
        return False

if __name__ == "__main__":
    test_connection()